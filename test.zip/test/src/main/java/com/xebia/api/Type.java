package com.xebia.api;

import com.fasterxml.jackson.annotation.JsonFormat;

@JsonFormat(shape = JsonFormat.Shape.STRING)
public enum Type {

    ING(0);

    private int value;

    Type(final int value) {
        this.value = value;
    }

    /**
     * Return the value appropriate for when storing a persistent value.
     *
     * @return the value.
     */
    public int getValue() {
        return value;
    }

    /**
     * Instantiate an Type from its value.
     *
     * @param value
     *            the value obtained from {@link #getValue()}.
     * @return the equivalent enum or UKNOWN if no match.
     */
    public static Type fromValue(final int value) {
        switch (value) {
            case 0:
                return Type.ING;
            default:
                throw new IllegalArgumentException("Invalid value for Type: " + value);
        }
    }
}
