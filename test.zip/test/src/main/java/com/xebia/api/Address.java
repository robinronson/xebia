package com.xebia.api;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Address {

    private String street;
    private String housenumber;
    private String postalcode;
    private String city;
    private GeoLocation geoLocation;

    protected Address(final Builder builder){
        this.housenumber = builder.housenumber;
        this.street = builder.street;
        this.postalcode = builder.postalcode;
        this.city = builder.city;
        this.geoLocation = builder.geoLocation;
    }

    public Address(){}

    public String getStreet() {
        return street;
    }

    public String getHousenumber() {
        return housenumber;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public String getCity() {
        return city;
    }

    public GeoLocation getGeoLocation() {
        return geoLocation;
    }

    public static class Builder {
        private String street;
        private String housenumber;
        private String postalcode;
        private String city;
        private GeoLocation geoLocation;

        public Builder(final Address address) {

            street = address.getStreet();
            housenumber = address.getHousenumber();
            postalcode = address.getPostalcode();
            city = address.getCity();
            geoLocation = address.getGeoLocation();
        }

        @JsonProperty
        public Builder street(final String street){
            this.street = street;
            return this;
        }

        @JsonProperty
        public Builder housenumber(final String housenumber){
            this.housenumber = housenumber;
            return this;
        }

        @JsonProperty
        public Builder postalcode(final String postalcode){
            this.postalcode = postalcode;
            return this;
        }

        @JsonProperty
        public Builder city(final String city){
            this.city = city;
            return this;
        }

        @JsonProperty
        public Builder geoLocation(final GeoLocation geoLocation){
            this.geoLocation = geoLocation;
            return this;
        }

        public Address build() {
            return new Address(this);
        }

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }

        @Override
        public boolean equals(Object other) {
            return EqualsBuilder.reflectionEquals(this, other);
        }

        @Override
        public String toString() {
            return ToStringBuilder.reflectionToString(this);
        }


    }
}
