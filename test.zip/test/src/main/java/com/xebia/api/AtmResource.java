package com.xebia.api;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Path("/atms")
public class AtmResource {

    /**
     * Method to create a list of ATM objects at once.
     * @param createAtmListRequest List of ATM objects to be created in the backend.
     * @return Created list of ATM objects along with the backend ID which is created for that object.
     * @throws Exception
     */
    @POST
    @Path("/create")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response createListATM(
            final CreateAtmListRequest createAtmListRequest
             ) throws Exception {

        List<Atm> createdAtmList = new ArrayList();
        for(Atm atm : createAtmListRequest.getAtmList()){
            Random random = new Random();
            Atm createdAtm = new Atm.Builder(atm).id(random.nextLong()).build();
            createdAtmList.add(createdAtm);
        }

        CreateAtmListRequest createdAtmListResponse = new CreateAtmListRequest();
        createdAtmListResponse.setAtmList(createdAtmList);

        ObjectMapper objectMapper = new ObjectMapper();

        return Response.status(201).entity(objectMapper.writeValueAsString(createdAtmListResponse)).build();

    }

    /**
     * Method to retrieve a list of ATM objects.
     * @return list of atm objects.
     * @throws Exception
     *
     * Currently this method is throwing an exception because the service is not correctly returning a proper JSON response.
     */
    @GET
    @Path("/get")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getListATM() throws Exception {

        final String url = "https://www.ing.nl/api/locator/atms/";

        DefaultHttpClient httpClient = new DefaultHttpClient();
        HttpGet getRequest = new HttpGet(
                url);
        getRequest.addHeader("accept", "application/json");

        HttpResponse response = httpClient.execute(getRequest);

        if (response.getStatusLine().getStatusCode() != 200) {
            throw new RuntimeException("Failed : HTTP error code : "
                    + response.getStatusLine().getStatusCode());
        }

        ObjectMapper objectMapper = new ObjectMapper();
        CreateAtmListRequest atmList = objectMapper.readValue(response.getEntity().getContent(), CreateAtmListRequest.class);

        return Response.status(200).entity(objectMapper.writeValueAsString(atmList)).build();

    }
}