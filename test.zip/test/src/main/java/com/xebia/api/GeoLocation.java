package com.xebia.api;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class GeoLocation {

    private double lat;
    private double lng;

    protected GeoLocation(final Builder builder){
        this.lat = builder.lat;
        this.lng = builder.lng;
    }

    public GeoLocation(){}

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }

    public static class Builder {
        private double lat;
        private double lng;

        public Builder(final GeoLocation geoLocation) {

            lat = geoLocation.getLat();
            lng = geoLocation.getLng();
        }

        @JsonProperty
        public Builder lat(final double lat){
            this.lat = lat;
            return this;
        }

        @JsonProperty
        public Builder lng(final double lng){
            this.lng = lng;
            return this;
        }

        public GeoLocation build() {
            return new GeoLocation(this);
        }

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }

        @Override
        public boolean equals(Object other) {
            return EqualsBuilder.reflectionEquals(this, other);
        }

        @Override
        public String toString() {
            return ToStringBuilder.reflectionToString(this);
        }


    }
}
