package com.xebia.api;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonAutoDetect
public class Atm {

    private Type type = Type.ING;
    private int distance;
    private Address address;
    private long id;

    protected Atm(final Builder builder){
        this.type = builder.type;
        this.distance = builder.distance;
        this.address = builder.address;
        this.id = builder.id;
    }

    public Atm(){

    }

    public Type getType() {
        return type;
    }

    public int getDistance() {
        return distance;
    }

    public Address getAddress() {
        return address;
    }

    public long getId() { return id; }

    public static class Builder {

        private Type type;
        private int distance;
        private Address address;
        private long id;

        public Builder(final Atm atm) {

            type = atm.getType();
            distance = atm.getDistance();
            address = atm.getAddress();
            id = atm.getId();
        }

        @JsonProperty
        public Builder type(final Type type){
            this.type = type;
            return this;
        }

        @JsonProperty
        public Builder distance(final int distance){
            this.distance = distance;
            return this;
        }

        @JsonProperty
        public Builder address(final Address address){
            this.address = address;
            return this;
        }

        @JsonProperty
        public Builder id(final long id){
            this.id = id;
            return this;
        }

        public Atm build() {
            return new Atm(this);
        }

        @Override
        public int hashCode() {
            return HashCodeBuilder.reflectionHashCode(this);
        }

        @Override
        public boolean equals(Object other) {
            return EqualsBuilder.reflectionEquals(this, other);
        }

        @Override
        public String toString() {
            return ToStringBuilder.reflectionToString(this);
        }
    }
}
